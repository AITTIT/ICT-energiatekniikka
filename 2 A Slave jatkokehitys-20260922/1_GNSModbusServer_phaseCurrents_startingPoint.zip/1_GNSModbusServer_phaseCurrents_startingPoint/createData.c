#include "createData.h"
#include "server_2.h"
#include "initialize.h"
#include <modbus/modbus.h>
#include <stdio.h>
#include <time.h>

void createData()
{

static float phase1_current=0;
static float phase2_current =0;
static float phase3_current =0; 


static int counter =0;
static time_t previousTime =0;
time_t currentTime;


#ifdef CREATEDEBUG
printf("\n CreateData One\n");
#endif
 
 
if(staticSignal == true){
     phase1_current = 0.15625;   //almost zero
     phase2_current = 300;      //typical current in 20kV operation
     phase3_current = 20000;   //shorted
}
else if (staticSignal ==false){ /*create signals which change over time. */

    //CODE NEEDED

    } //else if


/* copy-paste coding follows.   */

uint16_t phase1Registers[2];
uint16_t phase2Registers[2];
uint16_t phase3Registers[2];

#ifdef CREATEDEBUG
printf("\n CreateData two \n");
#endif

//CODE NEEDED: split the 32 bit current values into two 16 bit registers
//libmodbus has functions for this

//Below is the error.

mb_mapping -> tab_input_registers[0] = phase1Registers[0];
mb_mapping -> tab_input_registers[1] = phase1Registers[1];
mb_mapping -> tab_input_registers[2] = phase2Registers[0];
mb_mapping -> tab_input_registers[3] = phase2Registers[1];
mb_mapping -> tab_input_registers[4] = phase3Registers[0];
mb_mapping -> tab_input_registers[5] = phase3Registers[1];

#ifdef CREATEDEBUG
printf("\n CreateData four\n");
#endif
 

}
