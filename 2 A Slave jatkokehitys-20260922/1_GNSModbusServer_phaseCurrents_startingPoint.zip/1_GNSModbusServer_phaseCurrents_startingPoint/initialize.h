#ifndef INITIALIZE_H
#define INITIALIZE_H

//#define DEBUG_INIT 1

#define DISCRETE_INPUTS  0 //Read-only
#define COILS 0            //Read-Write
#define INPUT_REGISTERS 6   //Read-only
#define HOLDING_REGISTERS 0 //Read-Write

int initialize(const char *addressPtr, int portNumber);

#endif
